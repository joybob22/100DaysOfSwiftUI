//
//  UnitConversionChallengeApp.swift
//  UnitConversionChallenge
//
//  Created by Brayden Lemke on 12/15/21.
//

import SwiftUI

@main
struct UnitConversionChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
